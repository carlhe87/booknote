# =====================================================================
#  YOUR ACTUAL COPY -- this file is listed in .gitignore.
#  `git status` should never show this as a tracked/changed file.
#  This is just example content so you can see the shape; on the
#  company machine you'd fill in the real paths here instead.
# =====================================================================
@{
    ReportsFolder = 'C:\Users\hase\Company\Reports'
    LogArchive    = '\\fileserver01\shared\Logs'
    TemplateDir   = 'C:\Users\hase\Company\Templates'
    ArchiveDays   = 30
}
