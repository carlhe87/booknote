# =====================================================================
#  TEMPLATE -- commit this one to GitHub.
#  Copy it to paths.local.psd1 on each machine and fill in real values.
#  paths.local.psd1 is gitignored, so real paths never reach the repo.
# =====================================================================
@{
    ReportsFolder = 'C:\path\to\your\reports'
    LogArchive    = '\\your\log\share'
    TemplateDir   = 'C:\path\to\templates'
    ArchiveDays   = 30
}
