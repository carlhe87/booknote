# =====================================================================
#  Module manifest -- metadata about ReportTools.psm1.
#  Not strictly required for a simple module, but this is what lets
#  `Import-Module ReportTools` find it by name and validate it,
#  and what makes it look like a "real" module if you ever share it.
# =====================================================================
@{
    RootModule        = 'ReportTools.psm1'
    ModuleVersion     = '1.0.0'
    GUID              = 'b3f2a9d4-6c1e-4a3f-9e2b-1234567890ab'   # regenerate with New-Guid
    Author            = 'Hase'
    Description       = 'Report generation helpers.'
    PowerShellVersion = '5.1'

    FunctionsToExport = @('New-WeeklyReport')
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
}
