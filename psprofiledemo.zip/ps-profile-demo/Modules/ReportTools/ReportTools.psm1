# =====================================================================
#  Real logic lives here. This file only gets parsed/loaded the first
#  time New-WeeklyReport is actually called (via the stub in Profile.ps1).
#  No hardcoded paths -- everything comes from $Global:Config.
# =====================================================================

function New-WeeklyReport {
    [CmdletBinding()]
    param(
        [string]$OutputFolder = $Global:Config.ReportsFolder,
        [string]$TemplateFolder = $Global:Config.TemplateDir
    )

    if (-not $OutputFolder) {
        throw "ReportsFolder is not set. Check Config\paths.local.psd1."
    }

    Write-Verbose "Generating report into $OutputFolder using templates from $TemplateFolder"

    # ... your actual report-building logic goes here ...
    $reportPath = Join-Path $OutputFolder ("WeeklyReport_{0:yyyy-MM-dd}.txt" -f (Get-Date))
    "Report generated $(Get-Date)" | Out-File -FilePath $reportPath -Encoding utf8

    Write-Host "Report written to $reportPath"
}

# Only functions listed here (or in the manifest's FunctionsToExport)
# become visible outside the module -- helper functions you add later
# can stay private simply by not exporting them.
Export-ModuleMember -Function New-WeeklyReport
