# =====================================================================
#  A second module, shown without a manifest to demonstrate that a
#  bare .psm1 in the right folder is importable on its own -- a
#  manifest is optional until you want the extra metadata/control.
# =====================================================================

function Backup-Logs {
    [CmdletBinding()]
    param(
        [string]$Source = $Global:Config.LogArchive,
        [int]$RetentionDays = $(if ($Global:Config.ArchiveDays) { $Global:Config.ArchiveDays } else { 30 })
    )

    if (-not $Source) {
        throw "LogArchive is not set. Check Config\paths.local.psd1."
    }

    Write-Verbose "Backing up logs from $Source, retention $RetentionDays days"

    # ... your actual backup logic goes here ...
}

Export-ModuleMember -Function Backup-Logs
