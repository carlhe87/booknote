# =====================================================================
#  This is the file you'd point $PROFILE at (or dot-source from it).
#  Keep it small on purpose -- everything expensive is deferred until
#  a stub function is actually called.
# =====================================================================

$Script:RepoRoot = Split-Path -Parent $PSCommandPath

# ---------------------------------------------------------------------
# 1. Load local, machine-specific config (paths, etc.)
#    This file is gitignored -- it never leaves the company machine.
#    Copy Config\paths.example.psd1 to Config\paths.local.psd1 and
#    fill in real values the first time you set this up on a machine.
# ---------------------------------------------------------------------
$configPath = Join-Path $RepoRoot 'Config\paths.local.psd1'
if (Test-Path $configPath) {
    $Global:Config = Import-PowerShellDataFile -Path $configPath
}
else {
    Write-Warning "No local config found at $configPath. Copy Config\paths.example.psd1 to paths.local.psd1 and fill in your paths."
    $Global:Config = @{}
}

# ---------------------------------------------------------------------
# 2. Make your modules folder visible to Import-Module, for this
#    session only (doesn't touch the machine-wide PSModulePath).
# ---------------------------------------------------------------------
$modulesPath = Join-Path $RepoRoot 'Modules'
if ($env:PSModulePath -notlike "*$modulesPath*") {
    $env:PSModulePath = "$modulesPath$([IO.Path]::PathSeparator)$env:PSModulePath"
}

# ---------------------------------------------------------------------
# 3. Stub functions: cheap to define, do nothing until first called.
#    Calling one imports the real module, removes the stub, then
#    re-invokes itself with your original arguments. Every call after
#    the first goes straight to the real function -- no stub overhead.
# ---------------------------------------------------------------------
function global:New-WeeklyReport {
    Remove-Item Function:\New-WeeklyReport -ErrorAction SilentlyContinue
    Import-Module ReportTools -Force
    New-WeeklyReport @args
}

function global:Backup-Logs {
    Remove-Item Function:\Backup-Logs -ErrorAction SilentlyContinue
    Import-Module FileOps -Force
    Backup-Logs @args
}

# Add one stub per module/function group as your script grows.
# The profile itself never gets slower -- only using a feature does,
# and only the first time per session.
